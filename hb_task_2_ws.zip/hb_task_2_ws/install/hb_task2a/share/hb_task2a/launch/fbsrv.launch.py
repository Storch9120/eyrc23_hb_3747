from launch import LaunchDescription
from launch_ros.actions import Node
def generate_launch_description():
    ld = LaunchDescription()
    feedback_node = Node(
        package="hb_task2a",           # Enter the name of your ROS2 package
        executable="feedback.py",    # Enter the name of your executable
    )
    service_node = Node(
        package="hb_task2a",           # Enter the name of your ROS2 package
        executable="service_node.py",    # Enter the name of your executable
    )
    
    return LaunchDescription([
        feedback_node,
        service_node,
    ])