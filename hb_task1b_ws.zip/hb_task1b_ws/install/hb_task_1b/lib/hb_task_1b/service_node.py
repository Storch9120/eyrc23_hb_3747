#!/usr/bin/python3
# EASY-INSTALL-DEV-SCRIPT: 'hb-task-1b==0.0.0','service_node.py'
__requires__ = 'hb-task-1b==0.0.0'
__import__('pkg_resources').require('hb-task-1b==0.0.0')
__file__ = '/home/furquan/eyrc_hb/hb_task1b_ws/build/hb_task_1b/scripts/service_node.py'
with open(__file__) as f:
    exec(compile(f.read(), __file__, 'exec'))
